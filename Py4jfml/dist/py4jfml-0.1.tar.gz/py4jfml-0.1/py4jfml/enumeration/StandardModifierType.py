class StandardModifierType:
    '''
    Python class for StandardModifierType
    '''

    ABOVE="above"
    ANY="any"
    BELOW="below"
    EXTREMELY="extremely"
    INTENSIFY="intensify"
    MORE_OR_LESS="more_or_less"
    NORM="norm"
    NOT="not"
    PLUS="plus"
    SELDOM="seldom"
    SLIGHTLY="slightly"
    SOMEWHAT="somewhat"
    VERY="very"