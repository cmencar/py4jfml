class StandardTconormType:
    '''
    Python class StandardTconormType
    '''
    MAX="MAX"
    PROBOR="PROBOR"
    BSUM="BSUM"
    DRS="DRS"
    ESUM="ESUM"
    HSUM="HSUM"
    NILMAX="NILMAX"