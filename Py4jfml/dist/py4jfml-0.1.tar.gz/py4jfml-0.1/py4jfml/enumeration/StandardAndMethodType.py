class StandardAndMethodType:
    '''
    Python class for StandardAndMethodType
    '''
    MIN="MIN"
    PROD="PROD"
    BDIF="BDIF"
    DRP="DRP"
    EPROD="EPROD"
    HPROD="HPROD"
    NILMIN="NILMIN"