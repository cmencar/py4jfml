class MonotonicInterpolationMethodType:
    '''
    Python class for monotonicInterpolationMethodType
    '''

    LINEAR="linear"
    CUBIC="cubic"
