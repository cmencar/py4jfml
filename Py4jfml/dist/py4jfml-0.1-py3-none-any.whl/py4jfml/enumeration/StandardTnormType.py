class StandardTnormType:
    '''
    Python class for StandardTnormType
    '''
    MIN="MIN"
    PROD="PROD"
    BSUM="BSUM"
    DRS="DRS"
    EPROD="EPROD"
    HPROD="HPROD"
    NILMIN="NILMIN"