class StandardAccumulationType:
    '''
    Python class for StandardAccumulationType
    '''
    MAX="MAX"
    PROBOR="PROBOR"
    BSUM="BSUM"
    DRS="DRS"
    ESUM="ESUM"
    HSUM="HSUM"
    NILMAX="NILMAX"