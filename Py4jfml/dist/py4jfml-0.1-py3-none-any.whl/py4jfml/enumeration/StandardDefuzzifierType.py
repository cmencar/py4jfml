class StandardDefuzzifierType:
    '''
    Python class for StandardDefuzzifierType
    '''
    MOM="MOM"
    LM="LM"
    RM="RM"
    COG="COG"
    COA="COA"