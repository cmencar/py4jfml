class TskTerm:
    '''
    The TskTerm Python class contains the Constant Field
    :param _ORDER_0
    :param _ORDER_1
    '''
    _ORDER_0 = 0
    _ORDER_1 = 1