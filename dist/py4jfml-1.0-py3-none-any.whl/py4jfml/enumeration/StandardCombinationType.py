class StandardCombinationType:
    '''
    Python class for StandardCombinationType
    '''
    WA="WA"