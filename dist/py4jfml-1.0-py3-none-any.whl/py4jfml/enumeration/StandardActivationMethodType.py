class StandardActivationMethodType:
    '''
    Python class for StandardActivationMethodType
    '''
    MIN="MIN"
    PROD="PROD"
    BDIF="BDIF"
    DRP="DRP"
    EPROD="EPROD"
    HPROD="HPROD"
    NILMIN="NILMIN"