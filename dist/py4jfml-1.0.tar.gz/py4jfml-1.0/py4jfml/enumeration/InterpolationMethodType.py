class InterpolationMethodType:
    '''
    Python class for InterpolationMethodType
    '''
    LINEAR="linear"
    LAGRANGE="lagrange"
    SPLINE="spline"





